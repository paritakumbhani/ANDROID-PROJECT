package com.example.finalproject;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class detailNewsarticle extends AppCompatActivity {
    private TextView titleview;
    private TextView fullview;
    private TextView urlview;
    private Button savenews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_newsarticle);
        Intent intent=getIntent();

        titleview=(TextView)findViewById(R.id.title);
        fullview=(TextView)findViewById(R.id.fullText);
        urlview=(TextView)findViewById(R.id.urlview);
        savenews=(Button)findViewById(R.id.save);
        String srticle=intent.getStringExtra(Title);
        titleview.setText(srticle);
        String full=intent.getStringExtra(Text);
        fullview.setText(full);
        String url=intent.getStringExtra(url);
        urlview.setText(url);

        Button save=findViewById(R.id.save);
         web1 helper=new web1(detailNewsarticle.this);
         final SQLiteDatabase db=helper.getWritableDatabase();
         boolean issave=true;
         save.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Button b= (Button



                         ) v;
                 String operation =b.getText().toString();
                 if(operation.equalsIgnoreCase("save"))
                 {
                     ContentValues v1=new ContentValues();
                     v1.put();

                 }

             }
         });

    }
}
