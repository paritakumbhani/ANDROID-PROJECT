package com.example.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class News_detail_page_b extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_b);

        // get the intent that got us here
        Intent fromPrevious = getIntent();

        String previousTyped = fromPrevious.getStringExtra("typed");




    }


    private class AsyncListViewLoader extends
            AsyncTask<String, Void, List<NewsArticle_b>> {

        @Override
        protected List<NewsArticle_b> doInBackground(String... strings) {

            String newsDetail =null;
            List<NewsArticle_b> result = new ArrayList<NewsArticle_b>();
            try {
                URL u = new URL(strings[0]);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                conn.setRequestMethod("GET");
                conn.connect();
                InputStream is = conn.getInputStream();

                // Read the stream
                BufferedReader  bufferedReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                StringBuilder stringBuilder =new StringBuilder();
                String line = null;

                while ( ( line= bufferedReader.readLine() )!= null ) {

                    stringBuilder.append(line + "\n");
                }

                newsDetail = stringBuilder.toString();


                String JSONResp = new String(newsDetail);

                JSONObject jsonObject = new JSONStringer(JSONResp);

                return result;
            }
            catch(Throwable t) {
                t.printStackTrace();
            }

            return null;
        }

        private NewsArticle_b crowllingData(JSONObject obj) throws JSONException {
            String title = obj.getString("title");
            String text = obj.getString("text");
            String url = obj.getString("url");


            return new NewsArticle_b(title, text, url);
        }

        }
    }
}

