package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class News_Search_Page_b extends AppCompatActivity {


    private EditText search;
    private Button serachB;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newsfeed);
        search = findViewById(R.id.searchbox);
        serachB=findViewById(R.id.search_button);
        serachB.setOnClickListener(v -> {
            String text=search.getText().toString();
               Toast.makeText(getBaseContext(),"please enter a search text",Toast.LENGTH_LONG).show();
            Intent nextPage = new Intent(News_Search_Page_b.this, News_detail_page_b.class);
            nextPage.putExtra("typed", search.getText().toString());


            //Now make the transition:
            startActivity(nextPage);
          });
    }
}
