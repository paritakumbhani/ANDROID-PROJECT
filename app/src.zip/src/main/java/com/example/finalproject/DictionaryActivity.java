package com.example.finalproject;

public class DictionaryActivity {
}
