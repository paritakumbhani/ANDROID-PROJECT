package com.example.finalproject;

public class AppUtil {
}
