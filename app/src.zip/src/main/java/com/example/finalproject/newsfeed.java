package com.example.finalproject;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class newsfeed extends AppCompatActivity {


    private EditText search;
    private Button serachB;
    private Button newsearchclear;
    private Button newssearchhelp;
    private ListView listView;
    private ProgressBar p;
    private ArrayList<NewArticle> news=new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newsfeed);
        search=findViewById(R.id.searchbox);
        serachB=findViewById(R.id.search_button);
        listView=findViewById(R.id.listview);
        p=findViewById(R.id.progressBar);

        serachB.setOnClickListener(v -> {
            String text=search.getText().toString();
            if(text==null  || text.length()==0)
            {
                Toast.makeText(getBaseContext(),"please enter a search text",Toast.LENGTH_LONG).show();


            }
            else
            {
                p.setVisibility(View.VISIBLE);
                p.setMax(100);

            }
        });
        newsearchclear=findViewById(R.id.clear);
        newsearchclear.setOnClickListener(v -> {
            AlertDialog.Builder b=new AlertDialog.Builder(newsfeed.this);
            b.setMessage("clear text")
                    .setPositiveButton("yes",(dialog, which) -> {
                        search.getText().clear();
                    })
                    .setNegativeButton("cancel",null)
                    .setCancelable(false);
            AlertDialog alert= b.create();
            alert.show();
        });
        newssearchhelp=findViewById(R.id.help);
        newssearchhelp.setOnClickListener(v -> {
            AlertDialog.Builder b1=new AlertDialog.Builder(newsfeed.this);
            b1.setMessage("help");
        });
        p=findViewById(R.id.progressBar);
    }
    protected class web extends AsyncTask<String,Integer,List<NewArticle>>
    {
        protected List<NewArticle> doInBackground(String...strings) {
            String url = "http://webhose.io/filterWebContent?token=[YOUR_API_TOKEN]&format=xml&sort=crawled&q=Tesla";
            news = new ArrayList<>();
            publishProgress(25);
            JSONObject json=AppUtil.getJSONResponse(url);
            publishProgress(50);
            parseJSON(json);
            publishProgress(75);
            return  news;

        }
        protected void onProgressUpdate(Integer...values)
        {
            super.onProgressUpdate(values);
            p.setProgress(values[0]);
        }
        protected void onpreExecute()
        {
            super.onPreExecute();
        }
        protected  void onpostExecute(List<NewArticle> articles)
        {
            super.onPostExecute(articles);
            NewsArticleAdapter<NewArticle> list=new NewsArticleAdapter(getBaseContext(),news);
            listView.setAdapter(list);
            p.setVisibility(View.INVISIBLE);
            listView.setOnItemClickListener((parent,view,position,id)->{

               /*Snackbar.make(view,"clicked button",Snackbar.LENGTH_LONG).show();
                Intent next=new Intent(newsfeed.this,detailNewsarticle.class);
                NewArticle article=news.get(position);
                next.putExtra("Title",article.getTitle());
                next.putExtra("Text",article.getText());
                next.putExtra("url",article.geturl());
                startActivity(next);
*/
            });
        }
        private void parseJSON(JSONObject jsonRessponse)
        {
            try{
                JSONArray posts=jsonRessponse.getJSONArray("posts");
                for(int i=0;i<posts.length();i++)
                {
                    JSONObject json=posts.getJSONObject(i);
                    String title=JSONObject.getString("title");
                    if(title==null ||title.length()==0) continue;
                    String fulltext=JSONObject.getString("Text");
                    String url=JSONObject.getString("url");
                    news.add(new NewArticle(title,fulltext,url));


                }
            }
            catch(JSONException e)
            {
                e.printStackTrace();
            }
        }
    }
    protected class NewsArticleAdapter<T> extends ArrayAdapter<NewArticle>
    {
        public NewsArticleAdapter(Context context,ArrayList<NewArticle> articles)
        {
            super(context,0,articles);
        }
        public View getview(int position, View convertView, ViewGroup parent)
        {
            if(convertView==null)
            {
                convertView= LayoutInflater.from(getContext()).inflate(R.layout.article_item,parent,false);


            }
            NewArticle newArticle=news.get(position);
            TextView view=convertView.findViewById(R.id.title);
            view.setText(newArticle.getTitle());
            return convertView;
        }
    }
}
