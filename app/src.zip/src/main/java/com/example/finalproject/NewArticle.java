package com.example.finalproject;

public class NewArticle
{
    private String title;
    private String fullText;
    private String url;

    public NewArticle(String Title, String fullText, String url)
    {
        this.title=title;
        this.fullText=fullText;
        this.url=url;

    }
    public String getFullText()
    {
        return fullText;
    }
    public String getTitle()
    {
        return  title;
    }
    public String getUrl()
    {
        return url;
    }
}
